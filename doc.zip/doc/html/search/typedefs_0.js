var searchData=
[
  ['area',['Area',['../screen_8h.html#acfdfc42f6522d75fa3c16713afde8127',1,'screen.h']]]
];
