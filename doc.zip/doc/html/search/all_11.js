var searchData=
[
  ['t_5fcommand',['T_Command',['../command_8h.html#a0473597db8c45c0289b6b8e2f8abbe32',1,'command.h']]],
  ['total_5fdata',['TOTAL_DATA',['../screen_8c.html#afba5c5b9f73273ce653f890bb64740b0',1,'screen.c']]],
  ['types_2eh',['types.h',['../types_8h.html',1,'']]]
];
