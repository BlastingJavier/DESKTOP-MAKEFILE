var searchData=
[
  ['max_5fcasillas',['MAX_CASILLAS',['../game_8c.html#a4f925134933e44eea3e534ffe7a66da5',1,'game.c']]],
  ['max_5fid',['MAX_ID',['../types_8h.html#a1cdef4472847c938fc165b7d2737c4e4',1,'types.h']]],
  ['max_5finput_5fobj',['MAX_INPUT_OBJ',['../game_8c.html#abbb0e93ecf14e1b7f6ff77203323b577',1,'game.c']]],
  ['max_5flink',['MAX_LINK',['../link_8h.html#abfa744c8ca5b46f7f2a10aea53a4ec59',1,'link.h']]],
  ['max_5fspaces',['MAX_SPACES',['../space_8h.html#a5f54fd55f983a2e33ce076cd9f587e82',1,'space.h']]]
];
