var searchData=
[
  ['dice_2ec',['dice.c',['../dice_8c.html',1,'']]],
  ['dice_2eh',['dice.h',['../dice_8h.html',1,'']]]
];
