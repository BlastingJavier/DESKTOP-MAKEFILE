var searchData=
[
  ['name',['name',['../struct___object.html#a03fb9b8d91f071e8e30d669be79cc040',1,'_Object::name()'],['../struct___player.html#ac89715f913cc607b75eb7236765c41f5',1,'_Player::name()'],['../struct___space.html#aa1c9c994c2d16ecf3ef46138685fdfdc',1,'_Space::name()']]],
  ['num_5farray_5factual',['num_array_actual',['../struct___set.html#adbcdd0c8cc060118cf98296c617288d5',1,'_Set']]],
  ['numero_5fmax_5fobjects',['numero_max_objects',['../struct___inventory.html#a6752dd1a21aacdd25e4a81669d57d3b8',1,'_Inventory']]]
];
