var searchData=
[
  ['description_5fobject',['description_object',['../struct___game.html#a476fdc0cd3482e4d1c6d61f599c98537',1,'_Game']]],
  ['description_5fspace',['description_space',['../struct___game.html#a693233b66f955624007d3acd8d90f896',1,'_Game']]],
  ['dice',['dice',['../struct___game.html#af7004361a877182511a3e501b0949220',1,'_Game::dice()'],['../dice_8h.html#a5910ae86cf402855269700abd23e3976',1,'Dice():&#160;dice.h']]],
  ['dice_2ec',['dice.c',['../dice_8c.html',1,'']]],
  ['dice_2eh',['dice.h',['../dice_8h.html',1,'']]],
  ['dice_5fcreate',['dice_create',['../dice_8c.html#a220b32203d6426ed299b2efe106f3b6f',1,'dice_create(Id id):&#160;dice.c'],['../dice_8h.html#a220b32203d6426ed299b2efe106f3b6f',1,'dice_create(Id id):&#160;dice.c']]],
  ['dice_5fdestroy',['dice_destroy',['../dice_8c.html#adf79edbb3bc3616ae95110371660e20e',1,'dice_destroy(Dice *dice):&#160;dice.c'],['../dice_8h.html#adf79edbb3bc3616ae95110371660e20e',1,'dice_destroy(Dice *dice):&#160;dice.c']]],
  ['dice_5fget_5fid',['dice_get_id',['../dice_8c.html#a6989b5d04087170d40f3578e392edbd4',1,'dice_get_id(Dice *dice):&#160;dice.c'],['../dice_8h.html#a6989b5d04087170d40f3578e392edbd4',1,'dice_get_id(Dice *dice):&#160;dice.c']]],
  ['dice_5fget_5flast_5fshot',['dice_get_last_shot',['../dice_8c.html#a83854f5e8fea63286bfb860f8f79cfeb',1,'dice_get_last_shot(Dice *dice):&#160;dice.c'],['../dice_8h.html#a83854f5e8fea63286bfb860f8f79cfeb',1,'dice_get_last_shot(Dice *dice):&#160;dice.c']]],
  ['dice_5fprint',['dice_print',['../dice_8c.html#adc188c44ee8d1058c574f08ac39b5c6b',1,'dice_print(Dice *dice):&#160;dice.c'],['../dice_8h.html#adc188c44ee8d1058c574f08ac39b5c6b',1,'dice_print(Dice *dice):&#160;dice.c']]],
  ['dice_5froll',['dice_roll',['../dice_8c.html#a1470f66f84d57ede13acfe314153f39f',1,'dice_roll(Dice *dice):&#160;dice.c'],['../dice_8h.html#a1470f66f84d57ede13acfe314153f39f',1,'dice_roll(Dice *dice):&#160;dice.c'],['../command_8h.html#ace19ba2296a74e4aef53304e0934c50cafa5aea3821420c365b1a917fd285b600',1,'DICE_ROLL():&#160;command.h']]],
  ['direction',['DIRECTION',['../types_8h.html#aa268a41a13430b18e933ed40207178d0',1,'types.h']]],
  ['drop',['DROP',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50ca8b0b0025af76a3d8f0b7b1d4758e51a6',1,'command.h']]]
];
