var searchData=
[
  ['last_5fcmd',['last_cmd',['../struct___game.html#a27727b50ea0904a1fe9e1c55c27f2cf1',1,'_Game']]],
  ['last_5fshot',['last_shot',['../struct___dice.html#aed8d32d0bb7a19efab709c774153f36b',1,'_Dice']]],
  ['link_5fid',['link_id',['../struct___link.html#ae7170e271402273060da61adbac0a41d',1,'_Link']]],
  ['link_5fname',['link_name',['../struct___link.html#a6b9eabee0ea1bcca04ccdd9531561551',1,'_Link']]],
  ['link_5fstate',['link_state',['../struct___link.html#a72c07ec22edfeebc55e5b203f34985d4',1,'_Link']]],
  ['links',['links',['../struct___game.html#aaa2051f0487f13988148ffd7c5e7ec06',1,'_Game']]],
  ['location',['location',['../struct___object.html#a3c596b8898734de2f71fd1a33dfa72fb',1,'_Object']]]
];
