var searchData=
[
  ['gdesc',['gdesc',['../struct___space.html#a0a71c4c0a4a1698f7d860ba5b80beb7f',1,'_Space']]]
];
