var searchData=
[
  ['id',['id',['../struct___dice.html#ac5dba09cfd201b4a4a69d483111878e5',1,'_Dice::id()'],['../struct___object.html#a3cff7a0e8dc4e9d23895ed9af1b7653a',1,'_Object::id()'],['../struct___space.html#a70cb461deb9ac073e401b607339b567f',1,'_Space::id()']]],
  ['id_5farray',['id_array',['../struct___set.html#a218085180b67f253559c8460bbbf4329',1,'_Set']]],
  ['inventory_5fitems',['inventory_items',['../struct___player.html#af31e3b4e9ea2e1f65b0f645c49d9f0d5',1,'_Player']]]
];
