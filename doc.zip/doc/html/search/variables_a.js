var searchData=
[
  ['param',['param',['../struct___game.html#a50cfa27665ed86cd8c640a27b9f24af1',1,'_Game']]],
  ['player',['player',['../struct___game.html#a31406605782d71ec00c4bf258ea76267',1,'_Game']]],
  ['player_5fid',['player_id',['../struct___player.html#a97523810b1e2cff5d159f461c1acca69',1,'_Player']]]
];
