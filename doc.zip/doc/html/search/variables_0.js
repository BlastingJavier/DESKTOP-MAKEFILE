var searchData=
[
  ['_5f_5fdata',['__data',['../screen_8c.html#a34a5b96f7a2aa5db335b9fd09706cf0a',1,'screen.c']]]
];
