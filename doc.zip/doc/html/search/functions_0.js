var searchData=
[
  ['dice_5fcreate',['dice_create',['../dice_8c.html#a220b32203d6426ed299b2efe106f3b6f',1,'dice_create(Id id):&#160;dice.c'],['../dice_8h.html#a220b32203d6426ed299b2efe106f3b6f',1,'dice_create(Id id):&#160;dice.c']]],
  ['dice_5fdestroy',['dice_destroy',['../dice_8c.html#adf79edbb3bc3616ae95110371660e20e',1,'dice_destroy(Dice *dice):&#160;dice.c'],['../dice_8h.html#adf79edbb3bc3616ae95110371660e20e',1,'dice_destroy(Dice *dice):&#160;dice.c']]],
  ['dice_5fget_5fid',['dice_get_id',['../dice_8c.html#a6989b5d04087170d40f3578e392edbd4',1,'dice_get_id(Dice *dice):&#160;dice.c'],['../dice_8h.html#a6989b5d04087170d40f3578e392edbd4',1,'dice_get_id(Dice *dice):&#160;dice.c']]],
  ['dice_5fget_5flast_5fshot',['dice_get_last_shot',['../dice_8c.html#a83854f5e8fea63286bfb860f8f79cfeb',1,'dice_get_last_shot(Dice *dice):&#160;dice.c'],['../dice_8h.html#a83854f5e8fea63286bfb860f8f79cfeb',1,'dice_get_last_shot(Dice *dice):&#160;dice.c']]],
  ['dice_5fprint',['dice_print',['../dice_8c.html#adc188c44ee8d1058c574f08ac39b5c6b',1,'dice_print(Dice *dice):&#160;dice.c'],['../dice_8h.html#adc188c44ee8d1058c574f08ac39b5c6b',1,'dice_print(Dice *dice):&#160;dice.c']]],
  ['dice_5froll',['dice_roll',['../dice_8c.html#a1470f66f84d57ede13acfe314153f39f',1,'dice_roll(Dice *dice):&#160;dice.c'],['../dice_8h.html#a1470f66f84d57ede13acfe314153f39f',1,'dice_roll(Dice *dice):&#160;dice.c']]]
];
