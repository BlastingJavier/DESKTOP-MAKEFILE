var searchData=
[
  ['object',['object',['../struct___space.html#ac7dd2d0e61b879654be31d70a02fda76',1,'_Space']]],
  ['objects',['objects',['../struct___game.html#a1b9d5d4921be29c769b9bb6fa2422a29',1,'_Game::objects()'],['../struct___space.html#a661ed8b0fc8085b6db70188aa5085625',1,'_Space::objects()']]]
];
