var searchData=
[
  ['bg_5fchar',['BG_CHAR',['../screen_8c.html#a5e7c78a2c827b39d4464f2fc84058f87',1,'screen.c']]]
];
