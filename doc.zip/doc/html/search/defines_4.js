var searchData=
[
  ['id_5fdice',['ID_DICE',['../game_8c.html#ab24215a32624d156b5083d614acca631',1,'game.c']]],
  ['id_5fj',['ID_J',['../game_8c.html#ac1f2c6b97bcd6b90f6a8f121b4fc4205',1,'game.c']]],
  ['id_5fo',['ID_O',['../game_8c.html#a30de11e03af5daa34ea9a5472230525d',1,'game.c']]],
  ['inic_5fp',['INIC_P',['../game_8c.html#a6d3f0120558eff39995e58ced707b030',1,'game.c']]]
];
