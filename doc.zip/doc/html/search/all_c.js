var searchData=
[
  ['n_5fcallback',['N_CALLBACK',['../game_8c.html#a8366e5ad74afbbea0cd0a414770c304a',1,'game.c']]],
  ['n_5fcmd',['N_CMD',['../command_8c.html#ae180fe89f0ae48ce5c80ffaa18de9271',1,'command.c']]],
  ['name',['name',['../struct___object.html#a03fb9b8d91f071e8e30d669be79cc040',1,'_Object::name()'],['../struct___player.html#ac89715f913cc607b75eb7236765c41f5',1,'_Player::name()'],['../struct___space.html#aa1c9c994c2d16ecf3ef46138685fdfdc',1,'_Space::name()']]],
  ['no_5fid',['NO_ID',['../types_8h.html#a642e16f35aa1e585c25e405ede76e115',1,'types.h']]],
  ['north',['NORTH',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50cad0611de6f28d4a9c9eac959f5344698e',1,'command.h']]],
  ['num_5farray_5factual',['num_array_actual',['../struct___set.html#adbcdd0c8cc060118cf98296c617288d5',1,'_Set']]],
  ['num_5fobj',['NUM_OBJ',['../graphic__engine_8c.html#a5c3a0114b1e58dd42011cae154c7827e',1,'graphic_engine.c']]],
  ['numero_5fmax_5fobjects',['numero_max_objects',['../struct___inventory.html#a6752dd1a21aacdd25e4a81669d57d3b8',1,'_Inventory']]]
];
