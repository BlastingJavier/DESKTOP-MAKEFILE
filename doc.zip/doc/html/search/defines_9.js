var searchData=
[
  ['total_5fdata',['TOTAL_DATA',['../screen_8c.html#afba5c5b9f73273ce653f890bb64740b0',1,'screen.c']]]
];
