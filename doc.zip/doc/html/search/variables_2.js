var searchData=
[
  ['description_5fobject',['description_object',['../struct___game.html#a476fdc0cd3482e4d1c6d61f599c98537',1,'_Game']]],
  ['description_5fspace',['description_space',['../struct___game.html#a693233b66f955624007d3acd8d90f896',1,'_Game']]],
  ['dice',['dice',['../struct___game.html#af7004361a877182511a3e501b0949220',1,'_Game']]]
];
